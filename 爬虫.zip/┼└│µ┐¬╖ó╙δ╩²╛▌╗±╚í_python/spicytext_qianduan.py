# 导包操作
#utf-8

from time import sleep
import requests
from selenium import webdriver
from selenium.webdriver.common.by import By
import os
from lxml import etree
import re
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
#from main_fuzhi import driver
# 在你的模块中定义一个标志
loaded = False
# 用于测试函数的url
url1 = "https://new.qq.com/omn/20220311/20220311A09D5Z00.html"
ID = "5-2-"
# 设计一个spicy函数，抓取文章内容和图片，并将内容保存为Markdown文件
def spicy(url, path):
    # 根据网页的格式，发起一个get请求拿到响应数据 #get无法拿到shadow dom！
   # url='https://finance.huanqiu.com/article/4GCHBPIrhxq'
    #title="5-2-FESCO郝杰：人力资源服务业在新格局下的挑战与机遇"
   # path=f"./data/{title}/"

    # 创建Edge浏览器驱动实例
    option = webdriver.EdgeOptions()
    extension_path = r'C:\Users\LYKJ\PycharmProjects\web21009290061\selenium test1.crx'#记得把这个改为你的插件所在地址，同时记得把插件中的网址改为你需要开关影子根的网址.
    option.add_extension(extension_path)
    #option.add_argument("--headless")    #一个很无语的事情，无头模式无法加载shadow dom！！！
    driver = webdriver.Edge(options=option)  # 打开edge浏览器
    #driver.minimize_window()

    global loaded
    # 如果没有加载过，执行慢启动的逻辑
    if not loaded:
        print("慢启动中...")
        # 这里放入你的慢启动逻辑，如加载网页、初始化等
        sleep(10)
        # 设置标志为已加载
        loaded = True

    # 打开指定网址
    driver.get(url)
    sleep(10)
    # 使用 JavaScript 执行操作以访问 Shadow DOM 中的元素
    script_biaoti = """
        const articleContainerTemplate = document.querySelector('article-container-template');
        const firstRoot = articleContainerTemplate.shadowRoot;
        const articleHeadTemplate = firstRoot.querySelector('article-head-template');
        const secondRoot = articleHeadTemplate.shadowRoot;

        return secondRoot.innerHTML;
    """
    script_zhengwen = """
        const articleContainerTemplate1 = document.querySelector('article-container-template');
        const firstRoot1 = articleContainerTemplate1.shadowRoot;
        const layoutBlockTemplate = firstRoot1.querySelector('layout-block-template');
        const secondRoot1 = layoutBlockTemplate.shadowRoot;
        const articleContentTemplate = secondRoot1.querySelector('article-content-template');
        const thirdRoot1 = articleContentTemplate.shadowRoot;

        return thirdRoot1.innerHTML;
    """
    elements_in_shadow_dom_biaoti = driver.execute_script(script_biaoti)
    elements_in_shadow_dom_zhengwen = driver.execute_script(script_zhengwen)
    # 下列是不使用lxml的可能操作
    #title_html=elements_in_shadow_dom_biaoti
    #div_html=elements_in_shadow_dom_zhengwen
    #title = title_html.find_element(By.CSS_SELECTOR, 'h1').text
    #div=div_html.find_element()
    # 将请求返回的html形式数据通过etree.HTML函数返回一个解析对象。
    title_tree = etree.HTML(elements_in_shadow_dom_biaoti)
    div_tree = etree.HTML(elements_in_shadow_dom_zhengwen)
    # 通过xpath语法获取网页的所有文本。返回值是一个列表。其中，第1个元素为标题。将标题存储导title变量中
    title = title_tree.xpath('//h1/text()')[0]
    # 创建单独的文件夹，存储该新闻网页
    # print(f"开始爬取:{title}")
    title = ID + title
    #取内容
    # 获取新闻正文的所有标签以列表形式返回，存储到div
    div = div_tree.xpath("//div[@class='content']")[0]
    # print(div)
    # 将抓取的所有正文标签进行格式化，存储格式utf-8防止乱码
    html = etree.tostring(div, encoding="utf-8").decode("utf-8")
    # print(html)
    #下载图片到本地
    # 从所有正文标签中获取所有图片标签的url地址，并存储到srcs的列表中，并获取其属性值。xpath语法获取src属性值  '/@src'
    srcs = div.xpath(".//img/@src")     #此处srcs存储的是文章图片的url地址
    if srcs:  # 判断列表是否为空
        # 如果列表不为空，
        # 后续操作使用 covers 变量
        # 遍历所有图片的url
        a = 1
        for src in srcs:
            #print(src)
            download_url = "http:" + src
            # 发起get请求爬取图片
            img_resp = requests.get(download_url)
           # if img_resp.status_code == 200:
           #     print("图片下载成功")
           # else:
           #     print(f"图片下载失败，状态码: {img_resp.status_code}")
            # 为图片命名，名称不可重复
            # 对图片进行命名存入到对应目录中，后缀jpg格式
            # file_path = f"./data/{title}/"
            img_name = str(title + 'image') + str(a) + ".jpg"
            with open(f"{path}{img_name}", mode="wb") as f:
                f.write(img_resp.content)
            # 下载完成后将图片路径更改到本地图片路径
            html = html.replace(src, img_name)
            a += 1
            # 将图片和新闻内容存储到markdown中
    else:
        print("该新闻图片不存在")

    with open(f"{path}{title}.md", mode="w", encoding="utf-8")as f:
        f.write(html)



