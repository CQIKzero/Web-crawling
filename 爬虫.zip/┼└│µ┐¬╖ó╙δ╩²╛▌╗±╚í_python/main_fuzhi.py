#utf-8
from time import sleep
import requests
from selenium import webdriver
from selenium.webdriver.common.by import By
import os
from lxml import etree
import re
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
# 导入spicytext写好的爬虫函数
import spicytext_qianduan
try:
    # 创建Edge浏览器驱动实例
    option = webdriver.EdgeOptions()
    extension_path = r'C:\Users\LYKJ\PycharmProjects\web21009290061\selenium test1.crx'#记得把这个改为你的插件所在地址，同时记得把插件中的网址改为你需要开关影子根的网址.
    option.add_extension(extension_path)
    #option.add_argument("--headless")    #一个很无语的事情，无头模式无法加载shadow dom！！！
    driver = webdriver.Edge(options=option)  # 打开edge浏览器
    #driver.minimize_window()#最小化好像也会阻碍加载
    # 打开指定网址
    driver.get('https://finance.huanqiu.com/')
    sleep(5)
except:
    print("浏览器驱动异常")
# 切换到指定的 iframe
#iframe = driver.find_element(By.XPATH, '//*[channel-container-template]')
#driver.switch_to.frame(iframe)
# 使用 JavaScript 执行操作以访问 Shadow DOM 中的元素
script = """const channelContainer = document.querySelector('channel-container-template');
const channelContainerShadowRoot = channelContainer.shadowRoot;

const layoutBlocks = channelContainerShadowRoot.querySelectorAll('layout-block-template');
const layoutBlockShadowRoot = layoutBlocks[1].shadowRoot;

const layoutBdTemplate = layoutBlockShadowRoot.querySelector('layout-bd-template');
const thirdLayerShadowRoot = layoutBdTemplate.shadowRoot;

const sketchFeed = thirdLayerShadowRoot.querySelector('sketch-feed-template');
const sketchFeedShadowRoot = sketchFeed.shadowRoot;

return sketchFeedShadowRoot;

"""
# 执行 JavaScript
# elements_in_shadow_dom 现在包含了查找到的元素的 HTML 内容
# 进一步处理或打印这些内容
elements_in_shadow_dom_htmls = driver.execute_script(script)
elements_in_shadow_dom = elements_in_shadow_dom_htmls.find_elements(By.CSS_SELECTOR, ".feed-item.feed-item-a, .feed-item.feed-item-b")
#返回值为shadow dom时，可以用css方法查找。如果返回字符串，则用lxml转换为etree方法查找

# 使用XPath定位页面元素，找到新闻所在的元素
#text = driver.find_elements(By.XPATH, "//div[@class='feed-item feed-item-a' or @class='feed-item feed-item-b']")
text=elements_in_shadow_dom
# 定义文本数量，这里为100，定位到的新闻数量小于100则开始滑动窗口
n = 50
print("开始滑动窗口")
while len(text)<n:
    print("继续滑动")
    # 使用Selenium的execute_script方法执行JavaScript代码，实现页面滚动
    driver.execute_script('window.scrollBy(0,5000)')
    # 这行代码使用Selenium的find_elements方法查找页面上所有满足特定条件的HTML元素。
    #text = driver.find_elements(By.XPATH, "//div[@class='feed-item feed-item-a' or @class='feed-item feed-item-b']")
    # 使用 JavaScript 执行操作以访问 Shadow DOM 中的元素
    # 执行 JavaScript
    elements_in_shadow_dom_htmls = driver.execute_script(script)
    elements_in_shadow_dom = elements_in_shadow_dom_htmls.find_elements(By.CSS_SELECTOR,".feed-item.feed-item-a, .feed-item.feed-item-b")
    text=elements_in_shadow_dom
    print(f"当前新闻数量：{len(text)}/{n}")
    sleep(1)
sleep(5)
i=1
#判断是否存在文件夹，如果没有则创建一个
data_path = "./data/"
if not os.path.exists(data_path):
    os.mkdir(data_path)

#这是关于文章与模块的id标识，爬取时根据网站，模块替换excel表格中的id
ID = "5-2-"
illegal_chars = r'[<>:"/\|?*]'  # Windows不允许的非法字符正则表达式
# 通过循环获取数据中所有关于新闻的url，url存在于a元素的href属性对应的值中，这些a元素可以通过(target='_blank')属性值筛选。得到所有的url，然后根据url进行爬取(spicy函数)。
for t in text:
    print(f"{i}/{len(text)}")
    i += 1
    title = t.find_element(By.CSS_SELECTOR, "h4").text
    #与id拼接
    title = ID + title
    # 替换非法字符为下划线
    title = re.sub(illegal_chars, '_', title)
    print(title)
    #创建存储新闻的文件夹，首先判断是否已经存在
    if not os.path.exists(data_path+title):
        os.mkdir(data_path+title)
    else:
        print(f"已存在：{title}")
        if not len(os.listdir(data_path+title)) == 0:
            continue
    #筛选网页元素，找到封面，环球网使用的为img-item
    covers = t.find_element(By.CSS_SELECTOR, "a[target='_blank']")
    covers = covers.find_elements(By.CSS_SELECTOR, "div.img-item")
    if covers:  # 判断列表是否为空
        covers = covers[0]  # 如果列表不为空，选择第一个元素
        # 后续操作使用 covers 变量
        covers = covers.find_elements(By.CSS_SELECTOR, "img")
        a = 1
        # 爬取封面
        for src in covers:
            src = src.get_attribute("src")
            # download_url = "http:" + src
            # 发起get请求爬取图片
            img_resp = requests.get(src)
            # 为图片命名，名称不可重复
            # 对图片进行命名存入到对应目录中，后缀jpg格式
            file_path = f"./data/{title}/"
            img_name = str(title + 'cover') + str(a) + ".jpg"
            with open(f"{file_path}{img_name}", mode="wb") as f:
                f.write(img_resp.content)
            a += 1
    else:
        print("该新闻封面不存在")


    text1 = t.find_element(By.CSS_SELECTOR, "a[target='_blank']")
    # print(text1)
    text1 = text1.get_attribute("href")
    #text1 = 'http://finance.huanqiu.com/' + text1#似乎不需要加前缀网址
    #print(text1)


    try:
        spicytext_qianduan.spicy(text1, file_path)
        print(f"完成爬取:{title}")
    except:
        print("一个新闻的爬取出现错误，可能原因是标题出现非法字符")
        continue


# 关闭浏览器
driver.close()